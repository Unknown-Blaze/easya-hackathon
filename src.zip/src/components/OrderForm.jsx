// src/components/OrderForm.jsx (This is your main Landing Page content)
import React from 'react';
import {
  FiTarget, FiCheckSquare, FiLink, FiArchive, FiShield,
  FiHeart, FiUsers, FiTrendingUp,
  FiDollarSign, FiBarChart2, FiGlobe,
  FiExternalLink
} from 'react-icons/fi';

// Updated Styles for nGoDONATE brand consistency
const styles = {
  pageContainer: {
    fontFamily: "'Open Sans', sans-serif", // Body font
    color: '#333333', // Dark Gray text
    lineHeight: 1.6,
    backgroundColor: '#F9FAFB', // Light Gray background for sections outside hero
  },
  heroSection: {
    padding: '80px 20px',
    textAlign: 'center',
    background: 'linear-gradient(135deg, #0A2E36 0%, #005A67 100%)', // Deep Teal gradient
    color: 'white',
  },
  heroImageContainer: {
    maxWidth: '500px',
    margin: '30px auto 40px auto', // Increased bottom margin
    borderRadius: '8px',
    overflow: 'hidden',
    boxShadow: '0 10px 25px rgba(0,0,0,0.2)',
  },
  heroImage: {
    width: '100%',
    display: 'block',
  },
  heroHeadline: {
    fontFamily: "'Montserrat', sans-serif", // Heading font
    fontSize: '3em', // Slightly larger
    fontWeight: 700,
    marginBottom: '20px',
    letterSpacing: '-1px',
    color: '#ffffff',
    textShadow: '0 2px 4px rgba(0,0,0,0.3)',
  },
  heroSubheadline: {
    fontSize: '1.3em',
    maxWidth: '750px', // Wider for more text
    margin: '0 auto 40px auto',
    opacity: 0.9,
    lineHeight: 1.7,
  },
  ctaButton: {
    fontFamily: "'Montserrat', sans-serif",
    padding: '15px 30px', // Larger button
    fontSize: '1.1em',
    fontWeight: 600,
    color: '#FFFFFF',
    backgroundColor: '#007C8A', // Bright Teal accent
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    textDecoration: 'none',
    transition: 'transform 0.2s ease, box-shadow 0.2s ease, background-color 0.2s ease',
    boxShadow: '0 4px 15px rgba(0,0,0,0.1)',
    display: 'inline-block',
  },
  ctaButtonHover: {
    transform: 'translateY(-2px)',
    boxShadow: '0 6px 20px rgba(4, 75, 95, 0.25)', // Shadow from accent
    backgroundColor: '#006674', // Darker shade of Bright Teal
  },
  statsSection: {
    display: 'flex',
    justifyContent: 'space-around',
    alignItems: 'stretch',
    flexWrap: 'wrap',
    padding: '60px 20px',
    backgroundColor: '#FFFFFF', // White background for this section
    borderBottom: '1px solid #e0e0e0',
  },
  statWidget: {
    textAlign: 'center',
    padding: '25px',
    minWidth: '220px',
    flex: 1,
    margin: '10px',
    borderRadius: '8px',
    backgroundColor: '#F9FAFB',
    boxShadow: '0 3px 10px rgba(0,0,0,0.06)',
  },
  statIcon: {
    fontSize: '2.8em',
    color: '#007C8A', // Bright Teal
    marginBottom: '15px',
  },
  statValue: {
    fontFamily: "'Montserrat', sans-serif",
    fontSize: '2.2em',
    fontWeight: 'bold',
    color: '#0A2E36', // Deep Teal
    margin: '5px 0',
  },
  statLabel: {
    fontSize: '1em',
    color: '#555555', // Medium Gray
  },
  contentSection: {
    padding: '60px 20px',
    maxWidth: '1000px',
    margin: '0 auto',
  },
  sectionHeading: {
    fontFamily: "'Montserrat', sans-serif",
    fontSize: '2.4em',
    fontWeight: 600,
    color: '#0A2E36', // Deep Teal
    textAlign: 'center',
    marginBottom: '50px',
    position: 'relative',
  },
  sectionHeadingAfter: {
    content: "''",
    display: 'block',
    width: '80px',
    height: '4px',
    backgroundColor: '#007C8A', // Bright Teal
    margin: '15px auto 0',
    borderRadius: '2px',
  },
  paragraph: {
    fontSize: '1.1em',
    color: '#444444',
    marginBottom: '20px',
    textAlign: 'left', // Typically better for readability
    lineHeight: 1.7,
  },
  gridContainer: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', // Slightly larger minmax
    gap: '30px',
    marginTop: '30px',
  },
  card: {
    backgroundColor: '#FFFFFF', // White cards
    padding: '30px',
    borderRadius: '8px',
    boxShadow: '0 5px 15px rgba(0,0,0,0.07)',
    transition: 'transform 0.3s ease, box-shadow 0.3s ease',
    display: 'flex',
    flexDirection: 'column',
  },
  cardHover: {
    transform: 'translateY(-5px)',
    boxShadow: '0 8px 25px rgba(0,0,0,0.1)',
  },
  cardIconContainer: {
    fontSize: '2.2em',
    color: '#007C8A', // Bright Teal
    marginBottom: '20px',
    width: '60px',
    height: '60px',
    borderRadius: '50%',
    backgroundColor: '#e0f7fa', // Very light teal
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
  cardTitle: {
    fontFamily: "'Montserrat', sans-serif",
    fontSize: '1.5em',
    fontWeight: 600,
    color: '#0A2E36', // Deep Teal
    marginBottom: '15px',
  },
  cardText: {
    fontSize: '1em', // Standardized font size for card text
    color: '#555555',
    flexGrow: 1,
    lineHeight: 1.6,
  },
  xrplLink: {
    color: '#007C8A', // Bright Teal
    textDecoration: 'none',
    fontWeight: '600',
    display: 'inline-flex',
    alignItems: 'center',
  },
  xrplLinkIcon: {
    marginLeft: '5px',
  },
  footer: { // This footer is specific to the landing page content, not the global app footer
    textAlign: 'center',
    padding: '40px 20px',
    backgroundColor: '#0A2E36', // Deep Teal
    color: '#a0bacc', // Light Teal/Gray text
    fontSize: '0.95em',
  }
};

const OrderForm = () => { // Keeping filename OrderForm as per user's existing structure
  const [isCtaHovered, setIsCtaHovered] = React.useState(false);
  const [hoveredCard, setHoveredCard] = React.useState(null);

  // Updated Stats Data
  const statsData = [
    { icon: <FiDollarSign />, value: "1.2M+", label: "Funds Transparently Tracked" },
    { icon: <FiBarChart2 />, value: "500+", label: "Verified Project Milestones" },
    { icon: <FiGlobe />, value: "75+", label: "Supported Initiatives" },
    { icon: <FiHeart />, value: "10K+", label: "Impacted Beneficiaries" },
  ];

  const keyFeatures = [
    { icon: <FiTarget />, title: "Milestone-Based Escrow", description: "Donations are held in smart contracts on the XRPL and released only upon the successful completion of predefined project milestones." },
    { icon: <FiCheckSquare />, title: "Witness Chaining Verification", description: (<>Each milestone completion is verified through a decentralized network of witness servers. These servers attest to the achievement of milestones by validating submitted evidence, ensuring an unbiased confirmation process. Learn more at{' '} <a href="https://xrpl.org" target="_blank" rel="noopener noreferrer" style={styles.xrplLink}>xrpl.org <FiExternalLink style={styles.xrplLinkIcon} /></a>.</>) },
    { icon: <FiLink />, title: "On-Chain Transparency", description: "All transactions, including fund releases and milestone verifications, are recorded on the XRPL. This provides donors with real-time visibility into how their contributions are utilized." },
    { icon: <FiArchive />, title: "Decentralized Storage Integration", description: "Supporting documents, such as receipts and reports, are stored on decentralized platforms like IPFS. Links to these documents are embedded within transaction metadata, allowing for easy access and verification." },
    { icon: <FiShield />, title: "Regulatory Compliance", description: "The system is designed to align with regulatory frameworks, ensuring that all transactions and verifications meet legal standards and promote accountability." },
  ];

  const benefits = [
    { icon: <FiHeart />, title: "Enhanced Donor Trust", description: "By providing transparent, verifiable records of fund usage, donors can be confident that their contributions are making the intended impact." },
    { icon: <FiUsers />, title: "Improved Accountability", description: "NGOs are incentivized to meet project milestones efficiently, knowing that fund releases are contingent upon verified progress." },
    { icon: <FiTrendingUp />, title: "Scalable Solution", description: "The integration of XRPL and witness chaining offers a scalable model that can be adopted by NGOs worldwide to promote transparency and trust." },
  ];

  return (
    <div style={styles.pageContainer}>
      <section style={styles.heroSection}>
        <h1 style={styles.heroHeadline}>nGoDONATE: Amplify Your Impact. Transparently.</h1>
        <p style={styles.heroSubheadline}>
          Experience the future of charitable giving. nGoDONATE connects you directly to causes,
          powered by the XRP Ledger for unparalleled transparency and accountability.
        </p>
        <div style={styles.heroImageContainer}>
           <img
            src="https://images.unsplash.com/photo-1532629345422-7515f3d16bb6?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8Y2hhcml0eXxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=800&q=60" // A more hopeful/positive charity image
            alt="Empowering Communities through Transparent Donations"
            style={styles.heroImage}
          />
        </div>
        <a
          href="#learn-more"
          style={{ ...styles.ctaButton, ...(isCtaHovered ? styles.ctaButtonHover : {}) }}
          onMouseEnter={() => setIsCtaHovered(true)}
          onMouseLeave={() => setIsCtaHovered(false)}
        >
          Discover How It Works
        </a>
      </section>

      <section style={styles.statsSection}>
        {statsData.map((stat, index) => (
          <div key={index} style={styles.statWidget}>
            <div style={styles.statIcon}>{stat.icon}</div>
            <div style={styles.statValue}>{stat.value}</div>
            <div style={styles.statLabel}>{stat.label}</div>
          </div>
        ))}
      </section>

      <section id="learn-more" style={{ ...styles.contentSection, backgroundColor: '#FFFFFF'}}>
        <h2 style={styles.sectionHeading}>
          Project Overview
          <div style={styles.sectionHeadingAfter}></div>
        </h2>
        <p style={styles.paragraph}>
          nGoDONATE is designed to revolutionize NGO funding by integrating the XRP Ledger (XRPL)
          with a milestone-based escrow system, utilizing witness chaining for verification. We aim to create a
          trustworthy ecosystem where donors can confidently contribute, knowing their funds are managed and
          disbursed with utmost accountability and real-time visibility.
        </p>
      </section>

      <section style={{ ...styles.contentSection, backgroundColor: '#F9FAFB' }}>
        <h2 style={styles.sectionHeading}>
          Key Features
          <div style={styles.sectionHeadingAfter}></div>
        </h2>
        <div style={styles.gridContainer}>
          {keyFeatures.map((feature, index) => (
            <div
              key={index}
              style={{ ...styles.card, ...(hoveredCard === `feature-${index}` ? styles.cardHover : {}) }}
              onMouseEnter={() => setHoveredCard(`feature-${index}`)}
              onMouseLeave={() => setHoveredCard(null)}
            >
              <div style={styles.cardIconContainer}>{feature.icon}</div>
              <h3 style={styles.cardTitle}>{feature.title}</h3>
              <p style={styles.cardText}>{feature.description}</p>
            </div>
          ))}
        </div>
      </section>

      <section style={{ ...styles.contentSection, backgroundColor: '#FFFFFF' }}>
        <h2 style={styles.sectionHeading}>
          Benefits
          <div style={styles.sectionHeadingAfter}></div>
        </h2>
        <div style={styles.gridContainer}>
          {benefits.map((benefit, index) => (
            <div
              key={index}
              style={{ ...styles.card, ...(hoveredCard === `benefit-${index}` ? styles.cardHover : {}) }}
              onMouseEnter={() => setHoveredCard(`benefit-${index}`)}
              onMouseLeave={() => setHoveredCard(null)}
            >
              <div style={styles.cardIconContainer}>{benefit.icon}</div>
              <h3 style={styles.cardTitle}>{benefit.title}</h3>
              <p style={styles.cardText}>{benefit.description}</p>
            </div>
          ))}
        </div>
      </section>

      <footer style={styles.footer}>
        <p>nGoDONATE: Giving, Amplified.</p>
        <p>Building a future of trust and accountability in charitable endeavors.</p>
      </footer>
    </div>
  );
};

export default OrderForm;