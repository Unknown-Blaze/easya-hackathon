// src/pages/HomePage.jsx
import React from 'react';
import OrderForm from '../components/OrderForm'; // This is your main landing page content
import { Link } from 'react-router-dom';

// Updated styles for nGoDONATE
const homePageStyles = {
  pageContainer: {
    backgroundColor: '#F9FAFB', // Consistent light gray background
    minHeight: 'calc(100vh - 70px)', // Adjust if nav height changes
    // No specific padding here, OrderForm component handles its own layout
  },
  // FooterBox is now part of the global App layout or specific to other pages
  // For the landing page, its own footer is included in OrderForm.jsx
  // If you need a separate global footer, it should be in App.jsx
  globalFooter: { // Example if you wanted a separate very simple footer
    textAlign: 'center',
    padding: '20px',
    backgroundColor: '#0A2E36', // Deep Teal
    color: '#a0bacc',
    fontSize: '0.9em',
    borderTop: '1px solid #005A67'
  },
  adminLoginLink: {
    color: '#007C8A', // Bright Teal for links
    textDecoration: 'none',
    display: 'inline-block',
    marginTop: '10px',
    padding: '5px 10px',
    border: '1px solid #007C8A',
    borderRadius: '4px',
    transition: 'background-color 0.2s ease, color 0.2s ease',
  },
  adminLoginLinkHover: { // For JS hover
    backgroundColor: '#007C8A',
    color: 'white',
  }
};


const HomePage = () => {
  const [isAdminLinkHovered, setIsAdminLinkHovered] = React.useState(false);
  return (
    <div style={homePageStyles.pageContainer}>
      <OrderForm /> {/* This component now contains the full landing page content, including its own footer */}

      {/* Optional: If you want a small, separate footer for admin login on the homepage */}
      <div style={{ textAlign: 'center', padding: '30px 20px', backgroundColor: '#f0f2f5' }}>
        <Link
          to="/admin/login"
          style={{
            ...homePageStyles.adminLoginLink,
            ...(isAdminLinkHovered ? homePageStyles.adminLoginLinkHover : {})
          }}
          onMouseEnter={() => setIsAdminLinkHovered(true)}
          onMouseLeave={() => setIsAdminLinkHovered(false)}
        >
          Platform Administrator Login
        </Link>
      </div>
    </div>
  );
};

export default HomePage;